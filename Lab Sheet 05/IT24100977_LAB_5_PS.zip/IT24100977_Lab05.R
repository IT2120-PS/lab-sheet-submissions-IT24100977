setwd("C:\\Users\\IT24100944\\Desktop\\IT24100944")
getwd
getwd()
deliverytimes<-read.table("C:\\Users\\IT24100944\\Desktop\\IT24100944\\Exercise - Lab 05.txt",header=TRUE)
fix(deliverytimes)
names(deliverytimes)<-("X1")
attach(deliverytimes)
fix(deliverytimes)
histogram<-hist(X1,main="Histogram for delivery times",breaks=seq(20,70,length=10),right=FALSE)
#The distribution is approximately symmetric with most values concentrTED AROUND THE CENTER.
cum.freq<-cumsum(freq)
new<-c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}
plot(breaks,new,type="1",main="Cumalative Frequency Polygin for delivery times",xlab="Delivery times",ylab="cumulative frequency",ylim=c(0,max(cum.freq)))
cbind(Upper=breaks,CumFreq=new)
