setwd("C:\\Users\\IT24100977\\Desktop\\IT24100977")
> getwd()
[1] "C:/Users/IT24100977/Desktop/IT24100977"
> branch_data <- read.table("Exercise.txt",header=TRUE,sep=",")
> str(branch_data)
'data.frame':	30 obs. of  4 variables:
  $ Branch        : int  1 2 3 4 5 6 7 8 9 10 ...
$ Sales_X1      : num  3.4 4.1 2.8 5 3.7 4.5 3 4.9 3.2 2.5 ...
$ Advertising_X2: int  120 150 90 200 110 175 95 185 105 80 ...
$ Years_X3      : int  4 7 3 10 5 6 2 9 4 1 ...
> summary(branch_data)
Branch         Sales_X1     Advertising_X2     Years_X3    
Min.   : 1.00   Min.   :2.500   Min.   : 80.0   Min.   : 1.00  
1st Qu.: 8.25   1st Qu.:3.125   1st Qu.:101.2   1st Qu.: 3.25  
Median :15.50   Median :3.850   Median :132.5   Median : 5.50  
Mean   :15.50   Mean   :3.790   Mean   :134.8   Mean   : 5.70  
3rd Qu.:22.75   3rd Qu.:4.375   3rd Qu.:158.8   3rd Qu.: 7.75  
Max.   :30.00   Max.   :5.100   Max.   :210.0   Max.   :12.00  
> sapply(branch_data)
Error in match.fun(FUN) : argument "FUN" is missing, with no default
> sapply(branch_data,class)
Branch       Sales_X1 Advertising_X2       Years_X3 
"integer"      "numeric"      "integer"      "integer" 
> head(branch_data)
Branch Sales_X1 Advertising_X2 Years_X3
1      1      3.4            120        4
2      2      4.1            150        7
3      3      2.8             90        3
4      4      5.0            200       10
5      5      3.7            110        5
6      6      4.5            175        6
> boxplot(branch_data$Sales_X1,main="Boxplot of sales",ylab="Sales Amount", col="Lightblue",horizontal=FALSE)
> summary(branch_data$Sales_X1)
Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
2.500   3.125   3.850   3.790   4.375   5.100 
> fivenum(branch_data$Advertising_X2)
[1]  80.0 100.0 132.5 160.0 210.0
> summary(branch_data$Advertising_X2)
Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
80.0   101.2   132.5   134.8   158.8   210.0 
> IQR(branch_data$Advertising_X2)
[1] 57.5
> find_outliers <- function(x){}
> find_outliers <- function(x){
  + Q1 <-quantile(x,0.25)
  + Q3 <-quantile(x,0.75)
  + IQR_Value <-iqr(x)
  + 
    + lower_bound <- Q1-1.5*IQR_Value
    + upper_boud <- Q3+1.5*IQR_Value
    + outliers <-x[x<lower_bound|x>upper_bound]
    + return(outliers)
    + 
      + 
      + 
      + 
      + }
> outliers_years <- find_outliers(branch_data$Years_X3)
Error in iqr(x) : could not find function "iqr"
> 